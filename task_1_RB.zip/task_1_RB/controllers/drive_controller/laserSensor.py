class LaserSensors:
    def __init__(self, TIME_STEP, sensor_names, supervisor):
        self.sensors = {}
        for key, name in sensor_names.items():
            sensor = supervisor.getDevice(name)
            sensor.enable(TIME_STEP)
            self.sensors[key] = sensor
        
    def getValue(self, key):
        return self.sensors[key].getValue()
    
    def getSensors(self):
        return self.sensors