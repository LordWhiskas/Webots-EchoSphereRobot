from roboflow import Roboflow
import supervision as sv
import cv2

def network():
    rf = Roboflow(api_key="YOUR_API")
    project = rf.workspace("yolo-soccer-ball-test").project("soccer-balls-caltech-256")
    model = project.version(1).model

    result = model.predict("captured_image.png", confidence=80, overlap=0).json()

    if len(result['predictions']) != 0:
        labels = [item["class"] for item in result["predictions"]]

        detections = sv.Detections.from_roboflow(result)

        print(result['predictions'][0]['x'], result['predictions'][0]['y'], result['predictions'][0]['width'])

        # label_annotator = sv.LabelAnnotator()
        # bounding_box_annotator = sv.BoxAnnotator()

        # image = cv2.imread("captured_image.png")

        # annotated_image = bounding_box_annotator.annotate(
        #     scene=image, detections=detections)
        # annotated_image = label_annotator.annotate(
        #     scene=annotated_image, detections=detections, labels=labels)

        # sv.plot_image(image=annotated_image, size=(16, 16))

        return (result['predictions'][0]['x'], result['predictions'][0]['y'], result['predictions'][0]['width'])
    
    else:
        return None

if __name__ == "__main__":
    network()