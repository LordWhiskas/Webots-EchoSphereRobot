from controller import Robot, Supervisor
import speech_recognition as sr
import cv2
import numpy as np
import time
from test import network
from test_1 import navigation
from wheel import Wheels
from laserSensor import LaserSensors
import threading


TIME_STEP = 64
sensors = {}
search_step_time = 100

FIND_INTERVAL = 50  # Пример интервала вызова find в шагах симуляции
find_timer = FIND_INTERVAL

# rf = Roboflow(api_key="i6nHCahP0A5dx48dAyWi")
# project = rf.workspace("yolo-soccer-ball-test").project("soccer-balls-caltech-256")
# model = project.version(1).model

# Создаем экземпляр Supervisor
supervisor = Supervisor()

sound = []

lastState = 0

r = sr.Recognizer()

start_color = [1, 1, 1]  # Белый
end_color = [0, 0, 1]  # Красный

camera = supervisor.getDevice("camera")
camera.enable(TIME_STEP)

speaker = supervisor.getDevice("speaker")

# Получаем ссылку на узел PointLight через его DEF-имя
point_light = supervisor.getFromDef("light_1")

# Получаем доступ к полю 'on' узла PointLight
light_on_field = point_light.getField("on")
light_on_field.setSFBool(False)  # Выключаем свет

# Define the obstacle detection threshold
OBSTACLE_DETECTION_THRESHOLD = 800

# State constants
DRIVING = 0
AVOIDING = 1
CORNERED = 2
SLEEPING = 3
SEARCHING = 4
BALL_FOUND = 5
TURNING = 6

turn_direction = None
state = SLEEPING


# Initialize distance sensors
sensor_names = {
    'front_right': 'ds_right',
    'front_left': 'ds_left',
    'side_left': 'ds_left_left',
    'side_right': 'ds_right_right'
}
sensors = LaserSensors(sensor_names=sensor_names, TIME_STEP=TIME_STEP, supervisor=supervisor)



wheel_names = ['wheel1', 'wheel2', 'wheel3', 'wheel4']
wheels = Wheels(wheels_names=wheel_names, supervisor=supervisor)

# Avoidance counter to delay after detection
avoid_obstacle_counter = 0


def find(object):
    global state
    global end_color
    if object == "ball":
        image = camera.getImage()
        width = camera.getWidth()
        height = camera.getHeight()
        
        # Преобразуем строку байтов в массив NumPy
        image_np = np.frombuffer(image, np.uint8).reshape((height, width, 4))
        
        # Теперь можно преобразовать из BGRA в BGR и использовать OpenCV для обработки изображения
        image_cv = cv2.cvtColor(image_np, cv2.COLOR_BGRA2BGR)
        
        # Теперь можно применить flip и transpose, если это необходимо
        # image_cv = cv2.flip(cv2.transpose(image_cv), 0)
        
        # Сохраняем изображение на диск
        cv2.imwrite('captured_image.png', image_cv)

        result = network()
        print(result)
        if result != None:
            coordinates = navigation(result[0], result[1], result[2], supervisor)
            state = BALL_FOUND
            print(state)
            return True
        else:
            state = SEARCHING
            return False

def change_color(start_color, end_color, duration):
    start_time = supervisor.getTime()
    while supervisor.step(32) != -1:
        current_time = supervisor.getTime() - start_time
        t = current_time / duration
        if t >= 1.0:
            color_field.setSFColor(end_color)
            break
        interpolated_color = [start + (end - start) * t for start, end in zip(start_color, end_color)]
        color_field = point_light.getField("color")
        color_field.setSFColor(interpolated_color)

def voice_command(command):
    global sound
    if command == "start":
        change_color(start_color, end_color, 2)
        if speaker:
            speaker.playSound(speaker, speaker, "start.wav", 1.0, 1.0, 0, False)
        # Дождитесь окончания звука, продолжая цикл симуляции (замените 5 на длину звукового файла в секундах)
        start_sound_time = supervisor.getTime()
        while supervisor.getTime() - start_sound_time < 3:
            supervisor.step(64)

        # После окончания звука запустите второе изменение цвета
    elif command == "find":
        change_color(start_color, end_color, 2)
        if speaker:
            speaker.playSound(speaker, speaker, "find_ball.wav", 1.0, 1.0, 0, False)
        start_sound_time = supervisor.getTime()
        while supervisor.getTime() - start_sound_time < 4:
            supervisor.step(64)
    if command == "start":
        with sr.AudioFile('start.wav') as source:
            audio_data = r.record(source)
    if command == "find":
        with sr.AudioFile('find_ball.wav') as source:
            audio_data = r.record(source)
        
    # Распознавание речи из аудио
    try:
        text = r.recognize_google(audio_data)
        print("Recognized text: " + text)
    except sr.UnknownValueError:
        print("Speech Recognition could not understand audio")
    except sr.RequestError as e:
        print("Could not request results; {0}".format(e))
    if text == "hey robot turn on the light":
        light_on_field.setSFBool(True)  # Включаем свет
        change_color(end_color, start_color, 2)
        sound = speaker.playSound(speaker, speaker, "ai-denied.wav", 0.5, 1.0, 0, False)
    if text == "hey robot find the ball":
        change_color(end_color, start_color, 2)
        sound = speaker.playSound(speaker, speaker, "ai-denied.wav", 0.5, 1.0, 0, False)
        find("ball")
        

turning_time = 0
time_to_change_back = 0.0
while supervisor.step(TIME_STEP) != -1:
    print(f"state: {state}")
    left_speed = 0.0
    right_speed = 0.0
    sensor_values = {}
    
    if state == SLEEPING:
        voice_command("start")
        voice_command("find")
    
    if state == BALL_FOUND and supervisor.getTime() >= time_to_change_back:
        change_color(end_color, start_color, 2)  # Меняем цвет обратно
        break
    
    elif state == SEARCHING:
        sound = speaker.playSound(speaker, speaker, "security-scanning-01.wav", 0.5, 1.0, 0, True)
        speaker.stop("ai-denied.wav")
        speaker.stop("find_ball.wav")
        # Проверка, пора ли запускать функцию поиска
        if find_timer > 0:
            find_timer -= 1
        else:
            speaker.stop("security-scanning-01.wav")
            find_timer = FIND_INTERVAL
            left_speed = 0.0
            right_speed = 0.0
            result = find("ball")
            print(result)
            if result is True:
                change_color(start_color, end_color, 2)
                time_to_change_back = supervisor.getTime() + 2  # Устанавливаем время, когда нужно будет вернуть цвет
                if speaker:
                    speaker.playSound(speaker, speaker, "converted_confirmation.wav", 0.5, 1.0, 0, False)
                # while supervisor.getTime() - start_sound_time < 2:
                    # supervisor.step(64)
                # change_color(end_color, start_color, 2)
                print("state changed to BALL_FOUND")
                state = BALL_FOUND
                continue
    
        # Логика движения робота во время поиска
        if search_step_time > 0:
            search_step_time -= 1
            left_speed = 4.0
            right_speed = 4.0
        else:
            search_step_time = 100
            state = TURNING
            lastState = SEARCHING
            turning_time = 20
    
        # Проверка наличия препятствий перед роботом
        sensor_values = {key: sensors.getValue(key=key) for key in sensors.getSensors().keys()}
        is_obstacle_front = any(value < OBSTACLE_DETECTION_THRESHOLD for key, value in sensor_values.items() if 'front' in key)
        # Реакция на обнаружение препятствия
        if state == SEARCHING and is_obstacle_front:
            state = AVOIDING
            avoid_obstacle_counter = 20  # Задаём время для обхода препятствия
            lastState = SEARCHING
    
    elif state == DRIVING:
        print("----------------------")
        # Default speed
        left_speed = 4.0
        right_speed = 4.0

        # Read sensor values
        sensor_values = {key: sensors.getValue(key=key) for key in sensors.getSensors().keys()}

        # Check for obstacles using front sensors
        is_obstacle_front = any(
            value < OBSTACLE_DETECTION_THRESHOLD for key, value in sensor_values.items() if 'front' in key)
        
        
        
        # Inside the while loop
        if state == DRIVING and is_obstacle_front:
            state = AVOIDING
            avoid_obstacle_counter = 20  # Time to attempt to avoid the obstacle
    
    elif state == AVOIDING:
        if avoid_obstacle_counter > 0:
            avoid_obstacle_counter -= 1
            # If we detect obstacles on the side, consider that we are cornered
            sensor_values = {key: sensors.getValue(key=key) for key in sensors.getSensors().keys()}
            if sensor_values['side_left'] < OBSTACLE_DETECTION_THRESHOLD or sensor_values[
                'side_right'] < OBSTACLE_DETECTION_THRESHOLD and avoid_obstacle_counter == 20:
                state = CORNERED
                avoid_obstacle_counter = 40  # Give more time to get out of the corner
            else:
                # Normal avoiding behavior
                left_speed = -1.0
                right_speed = 1.0
        else:
            state = lastState
    elif state == CORNERED:
        if avoid_obstacle_counter > 0:
            avoid_obstacle_counter -= 1
            # Reverse a bit before turning
            left_speed = -2.0
            right_speed = -2.0
            sensor_values = {key: sensors.getValue(key=key) for key in sensors.getSensors().keys()}
            if avoid_obstacle_counter < 30 and sensor_values[
                'side_left'] > OBSTACLE_DETECTION_THRESHOLD:  # After reversing, start turning
                left_speed = 10.0
                right_speed = -1.0
            elif avoid_obstacle_counter < 30 and sensor_values['side_right'] > OBSTACLE_DETECTION_THRESHOLD:
                left_speed = -1.0
                right_speed = 10.0
        else:
            state = lastState
    elif state == TURNING:
        if turning_time > 0:
            turning_time -= 1
            left_speed = -1.0
            right_speed = 1.0
        else:
            state = lastState
    
    wheels.setVelocity(left_speed=left_speed, right_speed=right_speed)
        
    # Debug prints
    print("State: ", state)
    print("lastState: ", lastState)
    print("Avoiding Counter: ", avoid_obstacle_counter)
    for key, value in sensor_values.items():
        print(f"{key.capitalize()} sensor value: {value}")
    for idx in range(4):
        print(f"Motor_{idx} velocity: {wheels.getVelocity()[idx]}")
        
    # lidar_data = lidar.getRangeImage()
    # print(lidar_data)
    print("----------------------")