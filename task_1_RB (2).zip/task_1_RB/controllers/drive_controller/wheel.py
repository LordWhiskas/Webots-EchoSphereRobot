class Wheels:
    def __init__(self, wheels_names, supervisor):
        self.wheels = []
        for name in wheels_names:
            wheel = supervisor.getDevice(name)
            wheel.setPosition(float('inf'))
            wheel.setVelocity(0.0)
            self.wheels.append(wheel)
        self.left_speed = 0.0
        self.right_speed = 0.0
    
    def setVelocity(self, left_speed, right_speed):
        self.left_speed = left_speed
        self.right_speed = right_speed
        for i in range(2):
            self.wheels[i].setVelocity(left_speed)
        for i in range(2, 4):
            self.wheels[i].setVelocity(right_speed)

    def getVelocity(self):
        return [self.wheels[i].getVelocity() for i in range(4)]
