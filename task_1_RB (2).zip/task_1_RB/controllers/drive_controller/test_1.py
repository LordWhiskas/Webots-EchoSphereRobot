import numpy as np
import cv2

def navigation(ball_pixel_diameter, ball_pixel_x, ball_pixel_y, supervisor):
    # Предположим, что мы имеем информацию о мяче и камере
    ball_real_world_diameter = 5  # в метрах
    camera_fov_horizontal = 45  # горизонтальный угол обзора камеры в градусах
    camera_fov_vertical = 45  # вертикальный угол обзора камеры в градусах
    camera_height = 0.08  # высота камеры от земли в метрах
    image_width = 1080  # ширина изображения в пикселях
    image_height = 1080  # высота изображения в пикселях

    # Расчет расстояния до мяча
    def calculate_distance_to_ball(ball_real_world_diameter, ball_pixel_diameter, image_width):
        # Используем формулу треугольников для расчета расстояния до объекта
        # Какое-то предположение о фокусном расстоянии на основе угла обзора и ширины изображения
        focal_length = (image_width / 2) / np.tan(np.radians(camera_fov_horizontal / 2))
        return (ball_real_world_diameter * focal_length) / ball_pixel_diameter


    # Преобразование пиксельных координат в мировые координаты
    def pixel_to_world_coordinates(ball_pixel_x, ball_pixel_y, distance_to_ball, image_width, image_height, camera_height):
        # Преобразование пиксельных координат в координаты относительно центра изображения
        x_centered = ball_pixel_x - (image_width / 2)
        y_centered = ball_pixel_y - (image_height / 2)

        # Преобразование координат изображения в радианы
        angle_x = np.tan(x_centered / (image_width / 2) * np.radians(camera_fov_horizontal / 2))
        angle_y = np.tan(y_centered / (image_height / 2) * np.radians(camera_fov_vertical / 2))

        # Расчет мировых координат
        world_x = angle_x * distance_to_ball
        world_y = camera_height - (angle_y * distance_to_ball)

        return world_x, world_y


    # Пересчет координат с учетом положения и ориентации робота
    def correct_coordinates_with_robot_position(world_x, world_y, robot_position, robot_orientation):
        # Перевод угла робота в радианы
        robot_orientation_rad = np.radians(robot_orientation)

        # Корректировка координат с учетом поворота робота
        corrected_x = world_x * np.cos(robot_orientation_rad) - world_y * np.sin(robot_orientation_rad)
        corrected_y = world_x * np.sin(robot_orientation_rad) + world_y * np.cos(robot_orientation_rad)

        # Корректировка координат с учетом положения робота
        corrected_x += robot_position[0]
        corrected_y += robot_position[1]

        return corrected_x, corrected_y


    # Функция движения к мячу (это очень упрощенный пример)
    def navigate_to_ball(robot_world_x, robot_world_y):
        # Команды для управления двигателями робота будут здесь
        print(f"Driving to coordinates: X={robot_world_x}, Y={robot_world_y}")
        return (robot_world_x, robot_world_y)


    

    # Предположим, что позиция и ориентация робота известны
    robot_node = supervisor.getFromDef("ROBOT_1")

    robot_position = (robot_node.getPosition()[0], robot_node.getPosition()[1])



    robot_orientation = robot_node.getOrientation()[3]

    # Выполняем расчеты
    distance_to_ball = calculate_distance_to_ball(ball_real_world_diameter, ball_pixel_diameter, image_width)
    world_x, world_y = pixel_to_world_coordinates(ball_pixel_x, ball_pixel_y, distance_to_ball, image_width, image_height,
                                                camera_height)
    robot_world_x, robot_world_y = correct_coordinates_with_robot_position(world_x, world_y, robot_position,
                                                                        robot_orientation)

    # Инструктируем робота ехать к мячу
    navigate_to_ball(robot_world_x, robot_world_y)
    print(f"robot_position: {robot_position}, robot_orientation: {robot_orientation}, ball_pixel_diameter: {ball_pixel_diameter}, ball_pixel_x: {ball_pixel_x}, ball_pixel_y : {ball_pixel_y}")

if __name__ == "__main__":
    navigation()
